<?php

namespace Makoto\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MakotoAdminBundle extends Bundle
{
}
