<?php

namespace Makoto\ComponentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MakotoComponentBundle extends Bundle
{
}
