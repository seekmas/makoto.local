<?php

namespace Makoto\ExtensionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MakotoExtensionBundle extends Bundle
{
}
