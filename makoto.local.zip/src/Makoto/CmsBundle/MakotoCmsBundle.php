<?php

namespace Makoto\CmsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MakotoCmsBundle extends Bundle
{
}
