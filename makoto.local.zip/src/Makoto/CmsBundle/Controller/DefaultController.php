<?php

namespace Makoto\CmsBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $template_name = 'makoto_dna';

        $data = $this->$template_name();

        return $this->render('MakotoCmsBundle:Default:index.html.twig' ,
            [
                'data' => $data
            ]
        );
    }

    public function makotoAction( $template_name)
    {

        $data = $this->$template_name();
        
        return $this->render('MakotoComponentBundle:Pages:render_page.html.twig' , 
            [
                'template_name' => $template_name , 
                'data' => $data
            ]
        );
    }

    public function makoto_dna()
    {
         $page_data = [];

         $page_data['What_does_Makoto_Mean'] = $this->get('block.repository')->findBy(
            [
                'fromPage' => 'makoto_dna' ,
                'blockAlias' => 'What_does_Makoto_Mean' ,
            ]
        );

        $page_data['What_The_Meaning_of_Makoto'] = $this->get('block.repository')->findBy(
            [
                'fromPage' => 'makoto_dna' ,
                'blockAlias' => 'The_Meaning_of_Makoto' ,
            ]
        );

        return $page_data;
    }

    public function makoto_global()
    {
        $data = [];
        $data['Basic_Structure'] = $this->get('block.repository')->findOneBy(
                [
                    'blockAlias' => 'Basic_Structure'
                ]
        );

        $data['Kaizen_Consulting_Activities'] = $this->get('block.repository')->findOneBy(
                [
                    'blockAlias' => 'Kaizen_Consulting_Activities'
                ]
        );

        $data['Japan_Lean_Experience'] = $this->get('block.repository')->findOneBy(
                [
                    'blockAlias' => 'Japan_Lean_Experience'
                ]
        );

        $data['center_block'] = $this->get('block.repository')->findBy(
            [
                'blockAlias' => 'center_block' , 
            ]
        );

        $data['Kaizen_Training_Workshops'] = $this->get('block.repository')->findOneBy(
            [
                'blockAlias' => 'Kaizen_Training_Workshops' , 
            ]
        );

        return $data;
    }

    public function consulting()
    {
        return [];
    }

    public function contact()
    {

        $data = [];
        $data['Timeline'] = $this->get('timeline.repository')
                                                      ->createQueryBuilder('t')
                                                      ->select('t')
                                                      ->orderBy('t.year' , 'desc')
                                                      ->getQuery()
                                                      ->getResult();
        ladybug_dump( $data['Timeline'][0] );
        return $data;
    }

    public function service()
    {
        return [];
    }
}